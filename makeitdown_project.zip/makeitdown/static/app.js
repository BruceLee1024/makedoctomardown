// 全局变量
let uploadedFiles = [];

// 初始化
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    const uploadArea = document.getElementById('uploadArea');
    const fileInput = document.getElementById('fileInput');
    const formatSelect = document.getElementById('formatSelect');
    
    if (!uploadArea || !fileInput || !formatSelect) {
        console.error('必要的DOM元素未找到');
        return;
    }

    // 设置事件监听器
    setupEventListeners();
    
    // 检查服务器状态
    checkServerStatus();
    checkMcpStatus();
}

function setupEventListeners() {
    const uploadArea = document.getElementById('uploadArea');
    const fileInput = document.getElementById('fileInput');
    const formatSelect = document.getElementById('formatSelect');

    // 文件上传事件
    uploadArea.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', handleFileSelect);

    // 拖拽事件
    uploadArea.addEventListener('dragover', handleDragOver);
    uploadArea.addEventListener('dragleave', handleDragLeave);
    uploadArea.addEventListener('drop', handleDrop);

    // 格式选择事件
    formatSelect.addEventListener('change', handleFormatChange);
}

function handleDragOver(e) {
    e.preventDefault();
    document.getElementById('uploadArea').classList.add('dragover');
}

function handleDragLeave(e) {
    e.preventDefault();
    document.getElementById('uploadArea').classList.remove('dragover');
}

function handleDrop(e) {
    e.preventDefault();
    document.getElementById('uploadArea').classList.remove('dragover');
    
    const files = Array.from(e.dataTransfer.files);
    processFiles(files);
}

function handleFileSelect(e) {
    const files = Array.from(e.target.files);
    processFiles(files);
}

function processFiles(files) {
    const wordFiles = files.filter(file => 
        file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
        file.type === 'application/msword' ||
        file.name.toLowerCase().endsWith('.docx') ||
        file.name.toLowerCase().endsWith('.doc')
    );

    if (wordFiles.length === 0) {
        alert('请选择Word文档文件（.docx或.doc）');
        return;
    }

    wordFiles.forEach(file => {
        uploadedFiles.push({
            file: file,
            status: 'pending',
            progress: 0,
            result: null,
            error: null
        });
    });

    displayFileList();
    convertFiles();
}

function displayFileList() {
    const fileList = document.getElementById('fileList');
    
    if (uploadedFiles.length === 0) {
        fileList.style.display = 'none';
        return;
    }

    fileList.style.display = 'block';
    
    fileList.innerHTML = uploadedFiles.map((item, index) => `
        <div class="file-item" data-index="${index}">
            <div class="file-info">
                <div class="file-icon">📄</div>
                <div class="file-details">
                    <h4>${item.file.name}</h4>
                    <p>${formatFileSize(item.file.size)}</p>
                </div>
            </div>
            <div class="file-status ${item.status}">
                ${getStatusText(item.status)}
            </div>
        </div>
    `).join('');
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function getStatusText(status) {
    const statusMap = {
        'pending': '等待转换',
        'processing': '转换中...',
        'completed': '转换完成',
        'error': '转换失败'
    };
    return statusMap[status] || status;
}

function handleFormatChange() {
    const formatSelect = document.getElementById('formatSelect');
    const formatInfo = document.getElementById('formatInfo');
    
    if (formatSelect.value === 'table') {
        formatInfo.style.display = 'block';
    } else {
        formatInfo.style.display = 'none';
    }
}

async function convertFiles() {
    const resultsSection = document.getElementById('resultsSection');
    const resultsContainer = document.getElementById('resultsContainer');
    
    resultsSection.style.display = 'block';
    resultsContainer.innerHTML = '<div class="loading"><div class="loading-spinner"></div><p>正在转换文件...</p></div>';

    const formatSelect = document.getElementById('formatSelect');
    const formatType = formatSelect.value;
    const useMcp = document.getElementById('use-mcp')?.checked || false;

    for (let i = 0; i < uploadedFiles.length; i++) {
        const item = uploadedFiles[i];
        item.status = 'processing';
        displayFileList();

        try {
            const formData = new FormData();
            formData.append('file', item.file);
            formData.append('format', formatType);
            formData.append('use_mcp', useMcp);

            const response = await fetch('/convert', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const data = await response.json();
            
            if (data.success) {
                item.status = 'completed';
                item.result = data;
            } else {
                throw new Error(data.error || '转换失败');
            }
        } catch (error) {
            item.status = 'error';
            item.error = error.message;
        }
        
        displayFileList();
    }

    displayResults();
}

function displayResults() {
    const resultsContainer = document.getElementById('resultsContainer');
    const completedFiles = uploadedFiles.filter(item => item.status === 'completed');

    if (completedFiles.length === 0) {
        resultsContainer.innerHTML = '<p style="text-align: center; color: #666;">没有成功转换的文件</p>';
        return;
    }

    resultsContainer.innerHTML = completedFiles.map(item => `
        <div class="result-card">
            <div class="result-header">
                <h3 class="result-title">${item.file.name}</h3>
                <div class="result-actions">
                    <button class="action-btn" onclick="downloadFile('${item.file.name}', \`${escapeHtml(item.result.content)}\`)">
                        ⬇️ 下载
                    </button>
                    <button class="action-btn" onclick="copyToClipboard(\`${escapeHtml(item.result.content)}\`)">
                        📋 复制
                    </button>
                </div>
            </div>
            <div class="markdown-content">${escapeHtml(item.result.content)}</div>
        </div>
    `).join('');
}

function downloadFile(filename, content) {
    const blob = new Blob([content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename.replace(/\.[^/.]+$/, '') + '.md';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        // 显示复制成功提示
        const btn = event.target;
        const originalText = btn.textContent;
        btn.textContent = '✅ 已复制';
        setTimeout(() => {
            btn.textContent = originalText;
        }, 2000);
    }).catch(err => {
        console.error('复制失败:', err);
        alert('复制失败，请手动复制');
    });
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

async function checkServerStatus() {
    try {
        const response = await fetch('/health');
        if (response.ok) {
            document.getElementById('serverStatus').textContent = '✅ 服务器运行正常';
            document.getElementById('serverStatus').className = 'status online';
        } else {
            document.getElementById('serverStatus').textContent = '⚠️ 服务器连接异常';
            document.getElementById('serverStatus').className = 'status error';
        }
    } catch (error) {
        document.getElementById('serverStatus').textContent = '❌ 无法连接服务器';
        document.getElementById('serverStatus').className = 'status error';
    }
}

async function checkMcpStatus() {
    try {
        const response = await fetch('/mcp-status');
        const data = await response.json();
        
        const mcpCheckbox = document.getElementById('use-mcp');
        const mcpStatus = document.getElementById('mcp-status');
        
        if (data.mcp_running) {
            mcpStatus.textContent = 'MCP服务运行正常';
            mcpStatus.className = 'status online';
            if (mcpCheckbox) mcpCheckbox.disabled = false;
        } else {
            mcpStatus.textContent = 'MCP服务未运行';
            mcpStatus.className = 'status error';
            if (mcpCheckbox) {
                mcpCheckbox.disabled = true;
                mcpCheckbox.checked = false;
            }
        }
    } catch (error) {
        const mcpStatus = document.getElementById('mcp-status');
        const mcpCheckbox = document.getElementById('use-mcp');
        mcpStatus.textContent = 'MCP服务不可用';
        mcpStatus.className = 'status error';
        if (mcpCheckbox) {
            mcpCheckbox.disabled = true;
            mcpCheckbox.checked = false;
        }
    }
}

// 清理功能
function clearAllFiles() {
    uploadedFiles = [];
    document.getElementById('fileList').style.display = 'none';
    document.getElementById('resultsSection').style.display = 'none';
    document.getElementById('fileInput').value = '';
}

// 键盘快捷键
document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.key === 'k') {
        e.preventDefault();
        clearAllFiles();
    }
});